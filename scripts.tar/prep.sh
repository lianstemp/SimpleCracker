#!/bin/sh
sudo setfacl -m u:${USER}:rw /dev/kvm
